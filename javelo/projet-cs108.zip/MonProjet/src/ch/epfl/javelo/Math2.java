package ch.epfl.javelo;

public final class Math2 {
    private Math2 (){};
    public static int ceilDiv(int x, int y){
        int total = x+y-1;
        int div = total/y;
        return div;
    };
    public static double interpolate(double y0, double y1, double x){
        double coordonne = Math.fma((y1-y0),x,y0);
        return coordonne;
    };
    public static int clamp(int min, int v, int max){
        Preconditions.checkArgument(min<=max);
        if(v<=min){
            return min;
        }else{
            if(v>=max){
                return max;
            }else{
                return v;
            }
        }
    };
    public static double clamp(double min, double v, double max){
        Preconditions.checkArgument(min<=max);
        if(v<=min){
            return min;
        }else{
            if(v>=max){
                return max;
            }else{
                return v;
            }
        }
    };
    public static double asinh(double x){
        double asinh = Math.log(x+Math.sqrt(1+Math.pow(x,2)));
        return asinh;
    };
    public static double dotProduct(double uX, double uY, double vX, double vY){
        double dotProduct = uX*vX+uY*vY;
        return dotProduct;
    };
    public static double squaredNorm(double uX, double uY){
        double squar = Math.pow(uX,2)+Math.pow(uY,2);
        return squar;
    };
    public static double norm(double uX, double uY){
        double norm = Math.sqrt(squaredNorm(uX, uY));
        return norm;
    };
    public static double projectionLength(double aX, double aY, double bX, double bY, double pX, double pY){
        double uX = pX-aX;
        double uY = pY-aY;
        double vX = bX-aX;
        double vY = bY-aY;
        double length = dotProduct(uX, uY, vX, vY)/norm(vX, vY);
        return length;
    };
}
