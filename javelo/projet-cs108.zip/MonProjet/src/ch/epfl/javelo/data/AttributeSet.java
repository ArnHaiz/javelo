package ch.epfl.javelo.data;

import ch.epfl.javelo.Preconditions;

import java.util.StringJoiner;

public record AttributeSet(long bits) {
    public AttributeSet {
        Preconditions.checkArgument(Attribute.ALL.equals(bits));
    }
    public static AttributeSet of(Attribute... attributes) {
        long flag = 0;
        for(int i = 0; i<attributes.length; i++){
            flag = flag+(1L<<attributes[i].ordinal());
        };
        AttributeSet sample = new AttributeSet(flag);
        return sample;
    }
    public boolean contains(Attribute attribute) {
        if(attribute.equals(this)) {
            return true;
        }else{
            return false;
        }
    }
    public boolean intersects(AttributeSet that) {
        if((this.bits&that.bits)!=0) {
            return true;
        }else{
            return false;
        }
    }
    @Override
    public String toString() {
        StringJoiner j = new StringJoiner(",", "{", "}");
        for(int i = 0; i<Attribute.ALL.size(); i++){
            AttributeSet attributeSet = AttributeSet.of(Attribute.ALL.get(i));
            if(intersects(attributeSet)) {
                j.add(Attribute.ALL.get(i).toString());
            }
        }
        return j.toString();
    }
}
