package ch.epfl.javelo.projection;

import ch.epfl.javelo.Math2;

public final class WebMercator {
    public static double x(double lon) {
        double x = (1/(2*Math.PI))*(lon+Math.PI);
        return x;
    };
    public static double y(double lat) {
        double y = (1/(2*Math.PI))*(Math.PI- Math2.asinh(Math.tan(lat)));
        return y;
    };
    public static double lon(double x) {
        double lon = 2*Math.PI*x-Math.PI;
        return lon;
    };
    public static double lat(double y) {
        double lat = Math.atan(Math.sinh(Math.PI-2*Math.PI*y));
        return lat;
    };
}
