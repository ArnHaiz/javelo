package ch.epfl.javelo.projection;

import ch.epfl.javelo.Math2;
import ch.epfl.javelo.Preconditions;

public record PointCh(double e, double n) {
    public PointCh {
        Preconditions.checkArgument(((e>=SwissBounds.MIN_E)&&(e<=SwissBounds.MAX_E)&&(n>=SwissBounds.MIN_N)&&(n<=SwissBounds.MAX_N)));
    };
    public double squaredDistanceTo(PointCh that) {
        double uE = this.e-that.e;
        double uN = this.n-that.n;
        return Math2.squaredNorm(uE, uN);
    };
    public double distanceTo(PointCh that) {
        double uE = this.e-that.e;
        double uN = this.n-that.n;
        return Math2.norm(uE, uN);
    };
    public double lon() {
        double lon = Ch1903.lon(e,n);
        return lon;
    };
    public double lat() {
        double lat = Ch1903.lat(e,n);
        return lat;
    };
}
