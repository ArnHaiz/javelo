package ch.epfl.javelo;

public final class Q28_4 {
    public static int ofInt (int i) {
        int q28 = i<<4;
        return q28;
    };
    public static double asDouble (int q28_4) {
        int entier = Bits.extractSigned(q28_4, 4, 28);
        int p0 = Bits.extractSigned(q28_4, 0, 1);
        int p1 = Bits.extractSigned(q28_4, 1, 1);
        int p2 = Bits.extractSigned(q28_4, 2, 1);
        int p3 = Bits.extractSigned(q28_4, 3, 1);
        double nb = entier + Math.scalb(2,-4)*p0 + Math.scalb(2,-3)*p1 + Math.scalb(2,-2)*p2 + Math.scalb(2,-1)*p3;
        return nb;
    };
    public static float asFloat (int q28_4) {
        int entier = Bits.extractSigned(q28_4, 4, 28);
        int p0 = Bits.extractSigned(q28_4, 0, 1);
        int p1 = Bits.extractSigned(q28_4, 1, 1);
        int p2 = Bits.extractSigned(q28_4, 2, 1);
        int p3 = Bits.extractSigned(q28_4, 3, 1);
        float nb = entier + Math.scalb(2,-4)*p0 + Math.scalb(2,-3)*p1 + Math.scalb(2,-2)*p2 + Math.scalb(2,-1)*p3;
        return nb;
    };
}
